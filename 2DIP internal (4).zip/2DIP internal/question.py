from time import*
import threading
import time

player_answer_list=["No answer","No answer","No answer","No answer","No answer","No answer","No answer","No answer","No answer","No answer"]


correct_answer_list=["A","D","A","C","A","C","B","A","C","C"]




score=int(0)

answer_question=int(0)


def final_score():

    if score==5:
        print("")
        print("you need work on harder ")
        

    elif score==8:
        print("you are very close to excellence, an merit grade is been given.")
        
    if score==9:
            print("")
            print("Good Job, an excellence grade is been awarded.")
            print("")


            print("It will be nice if you have study to get the full marks!!!")

    elif score==10:
            print("")
            print("Well done full makrs with excelelence")
            print("")

            print("looks like you are well prepare for you exam!!")
    
    elif score==6:
            print("")
            print("you are very closed to merit an achieved is been awarded.")
            print("")
      
            

    elif score==7:
        print("")
        print("you are very close the excellence grade. a merit grade is been award ")

    else:
        print("")
        print("you really need work harder and harder.")
        print("")

        print("Keep trying and you will be better!! Marking schedule: E= 9-10, M = 7-8 A = 5-6 N = 0-4")            

        

            
def countdown():
    global time

    time=10
    

    for i in range(100):
        time=time-1
        sleep(1)

        if answer_question==10:
            break

    if answer_question==10:
        pass

    else:
        print("")
        print("yout time is out")
        sleep(1)
        print("marking answers")
        sleep(1)
        print("")
        

        for x in range(0,10,1):
            print("{}. {}".format(x+1, player_answer_list[x]))

            if player_answer_list[x]=="Correct":
                print("")
                sleep(0.5)

            elif player_answer_list[x]=="Wrong":
                print("Correct answer:{}".format(correct_answer_list[x]))
                sleep(0.5)
               
   
            elif player_answer_list[x]=="No answer":
                print("")        
                sleep(0.5)
        final_score()

countdown_thread = threading.Thread(target = countdown)
countdown_thread.start()

while answer_question <10:
#question 1

        print("1: what is the symbol for sodium element?? (10 point)")
        sleep(1.0)

        if time==0:
            break
        print("(A) Na")

        if time==0:
            break        
        print("(B) Mg")
     
        if time==0:
            break        
        print("(C) K")
        
        if time==0:
            break        
        print("(D) S")
      
        if time==0:
            break 

        answer_1=input("Please select your answer: ")
        answer_1=answer_1.upper()
        print("")

        if answer_1=="A":
            player_answer_list[0]="Right"
            score=score+1
            answer_question=1
#if answer not equal to A use wrong to replace the "No answer" in the correspond position in the player_answer_list
        else:
            player_answer_list[0]="Wrong"
            answer_question=1
            
# question 2    
        print("2. does all the organic compounds contain the carbon atom?: (10 point)")
        sleep(1.0)        
        if time==0:
            break        
        print("(A) Yes")
           
        if time==0:
            break        
        print("(B) No")
     
        if time==0:
            break        
        print("(C) some of them")
         
        if time==0:
            break        
        print("(D) none of them are correct")
    
        if time==0:
            break        
        answer_2=input("Please select your answer: ")
        answer_2=answer_2.upper()
        print("")
        if answer_2=="A":
            player_answer_list[1]="Right"
            score=score+1
            answer_question=2
        else:
            player_answer_list[1]="Wrong"
            answer_question=2
        if time==0:
            break        
#question 3 
        print("3. How many protons does sodium have?: (10 point)")

        if time==0:
            break        
        print("(A) 10")
       
        if time==0:
            break        
        print("(B) 12")
    
        if time==0:
            break        
        print("(C) 14")
       
        if time==0:
            break        
        print("(D) 17")
      
        if time==0:
            break        
        answer_3=input("Please select your answer: ")
        answer_3=answer_3.upper()
        print("")
        if answer_3=="B":
            player_answer_list[2]="Right"
            score=score+1
            answer_question=3
        else:
            player_answer_list[2]="Wrong"
            answer_question=3
        if time==0:
            break        
#question 4 
        print("4.what is the symbol for carbon?(10 point)")
        sleep(1.0)   
        if time==0:
            break        
        print("(A) C")
        
        if time==0:
            break        
        print("(B) O")
                    
        if time==0:
            break        
        print("(C) K")
                    
        if time==0:
            break        
        print("(D) Cl")
       
        if time==0:
            break        
        answer_4=input("Please select your answer: ")
        answer_4=answer_4.upper()
        print("")
        if answer_4=="A":
            player_answer_list[3]="Right"
            score=score+1
            answer_question=4
        else:
            player_answer_list[3]="Wrong"
            answer_question=4
        if time==0:
            break        
# question 5
        print("5. what is the electron arrangement of magnesium? (10 point)")
        sleep(1.0)                 
        if time==0:
            break        
        print("(A) 2,8")
                           
        if time==0:
            break        
        print("(B) 2,8,1")
              
        if time==0:
            break        
        print("(C) 2,8,3")
              
        if time==0:
            break        
        print("(D) 2,8,2")
    
        if time==0:
            break        
        answer_5=input("Please select your answer: ")
        answer_5=answer_5.upper()
        print("")
        if answer_5=="D":
            player_answer_list[4]="Right"
            score=score+1
            answer_question=5
        else:
            player_answer_list[4]="Wrong"
            answer_question=5
        if time==0:
            break        
#question 6 
        print("6. what is the electron arrangement of potassium> (10 point)")
        sleep(1.0) 
        if time==0:
            break        
        print("(A) 2,8,8,1")
         
        if time==0:
            break        
        print("(B) 2.8,8")
         
        if time==0:
            break        
        print("(C) 2,8,8,2")
            
        if time==0:
            break        
        print("(D) 2,8,8,3")
     
        if time==0:
            break        
        answer_6=input("Please select your answer: ")
        answer_6=answer_6.upper()
        print("")
        if answer_6=="A":
            player_answer_list[5]="Right"
            score=score+1
            answer_question=6
        else:
            player_answer_list[5]="Wrong"
            answer_question=6
        if time==0:
            break
# question 7 
        print("7. What is Zn? (10 point)")
        sleep(1.0)                  
        if time==0:
            break        
        print("(A) Magnesium")
                    
        if time==0:
            break        
        print("(B) Hydrogen")
              
        if time==0:
            break        
        print("(C) Gold")
              
        if time==0:
            break        
        print("(D) Zinc")
      
        if time==0:
            break        
        answer_7=input("Please select your answer: ")
        answer_7=answer_7.upper()
        print("D")
        if answer_7=="B":
            player_answer_list[6]="Right"
            score=score+1
            answer_question=7
        else:
            player_answer_list[6]="Wrong"
            answer_question=7
        if time==0:
            break            
# question 8 
        print("8.  DNA codes for proteins, which are the building blocks of organisms. What is the most abundant protein in the human body? (10 point)")
        sleep(1.0)
        if time==0:
            break        
        print("(A) Keratin")
                        
        if time==0:
            break        
        print("(B) Tubulin")
               
        if time==0:
            break        
        print("(C) Albumin")
                  
        if time==0:
            break        
        print("(D) Collagen")
        
        if time==0:
            break        
        answer_8=input("Please select your answer: ")
        answer_8=answer_8.upper()
        if answer_8=="D":
            player_answer_list[7]="Right"
            score=score+1
            answer_question=8
        else:
            player_answer_list[7]="Wrong"
            answer_question=8
        if time==0:
            break            
#question 9
        print("9.What is the most common isotope of hydrogen?(10 point)")
        sleep(1.0)                  
        if time==0:
            break        
        print("(A) protium")
                       
        if time==0:
            break        
        print("(B) Deuterium")
                   
        if time==0:
            break        
        print("(C) Tritum")
                
        if time==0:
            break        
        print("(D) None")
    
        if time==0:
            break        
        answer_9=input("Please select your answer: ")
        answer_9=answer_9.upper()
        print("")
        if answer_9=="A":
            player_answer_list[8]="Right"
            score=score+1
            answer_question=9
        else:
            player_answer_list[8]="Wrong"
            answer_question=9
        if time==0:
            break            
        #question 10
        print("10.What is its chemical formula for water?(10 point)")
        sleep(1.0)                 
        if time==0:
            break        
        print("(A) H2O2")
              
        if time==0:
            break        
        print("(B) O2")
                      
        if time==0:
            break        
        print("(C) H20")
        
        if time==0:
            break        
        print("(D) H2")
      
        if time==0:
            break        
        answer_10=input("Please select your answer: ")
        answer_10=answer_10.upper()
        if answer_10=="C":
            player_answer_list[9]="Correct"
            score=score+1
            answer_question=10
        else:
            player_answer_list[9]="incorrect"
            answer_question=10
        if time==0:
            break        
        
#if the player has answered 10 question in a specified time, print the correspond messege
if answer_question==10:
    sleep(1.0)
#print the checking answer message
    print("Marking the answer")
    print("")
    sleep(2.5)
    print("Your result:")
    sleep(0.5)
#print the player's answer in the player_answer_list in order.
    for order in range(0,10,1):
        print("{}. {}".format(order+1, player_answer_list[order]))
#if the answer equal to right, only print""
        if player_answer_list[order]=="Right":
            print("")
            sleep(0.5)
#if the answer equal to worng, print the explanation and correct answer.
        if player_answer_list[order]=="Wrong":
            print("Correct answer:{}".format(correct_answer_list[order]))
            sleep(0.5)
           
#run final_score function
    final_score()

    

        
    

    


      


    
        

    
       


    
    
    


    
