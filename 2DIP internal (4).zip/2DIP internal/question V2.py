from time import*
import threading
import time

# Make the player's answer list. In the beginning, all the answers were "No answers"
player_answer_list=[]
for i in range(0,10,1):
    player_answer_list.append("No answer")
    
questions = ["Question 1: What is the symbol for sodium element? )","(A) Na","(B) Mg", "(C) K", "(D) S",
            
            "2. does all the organic compounds contain the carbon atom?:", "(A) Yes", "(B) No", "(C) some of them", "(D) none of them are correct",

             "3. How many electrons does sodium atom have?: ", "(A) 10", "(B) 11", "(C) 14", "(D) 17",

             "4.what is the symbol for carbon?",  "(A) C", "(B) O", "(C) K", "(D) Cl",

             "5. what is the electron arrangement of magnesium?", "(A) 2,8", "(B) 2,8,1",  "(C) 2,8,3", "(D) 2,8,2",
            
            "6. what is the electron arrangement of potassium> ", "(A) 2,8,8,1", "(B) 2.8,8", "(C) 2,8,8,2", "(D) 2,8,8,3",

            "7. What is Zn? ", "(A) Magnesium", "(B) Hydrogen", "(C) Gold", "(D) Zinc",

            "8.  DNA codes for proteins, which are the building blocks of organisms. What is the most abundant protein in the human body? ", "(A) Keratin", "(B) Tubulin", "(C) Albumin", "(D) Collagen",

            "9.What is the most common isotope of hydrogen?", "(A) protium", "(B) Deuterium", "(C) Tritum", "(D) None", 

            "10.What is its chemical formula for water?", "(A) H2O2", "(B) O2", "(C) H20", "(D) H2"] 



correct_choices = ["A","A","B","A","D","A","B","D","A","C"] 

answers = ["The symbol for sodium element is Na", 

           "Yes, all the organic compounds contains the carbon atom", 

           "The sodium atom has 11 elections.", 

           "the symbol for the carbon is C", 

           "the electron arrangement for magnesium would be 2,8,2",
           
           "The electron arrangement for potassium would be 2,8,8,1",
           
           "THe Zn is the zinc element",
           
           "THe most abundant protein will be Collagen",
           
           "Protium (Hydrogen-1) is the lightest and by far the most common isotope of hydrogen",
           
           "the chemical formula for water would be H2"] 

 
#Set the score to 0 in the begining
score=int(0)

#Set the question_number to 0. The question_number is used to know how many question it has printed 
question_number=0

#Set the total_time to 100. The total_time is used to set the time that player can use to finish the quiz
total_time=100

#Set the answer_question to 0. The answer_question is used to know how many question the player has answered
answer_question=int(0)

#Define the final_score function. This function is used to output differnt messege when the player get different score
def final_score():
#if score more than 80 but less than 100, print the correspond message
    if score>80 :
        if score<100:
            print("")
            print("Well done!! Your final score is {}/100".format(score))
            print("")
#sleep(0.5��means that wait 0.5 second before doing the next thing
            sleep(0.5)
            print("You are very close to a full score! Keep learing and you will achieve it!!")
#if score equal to 100 ,print the correspond message
        elif score==100:
            print("")
            print("Congratulation!!! Your final score is {}/100".format(score))
            print("")
            sleep(0.5)
            print("Unbelieveable!!! You get the full score!!")
#if score less than 80 but bigger than 50, print the correspond message       
    elif score>= 50:
            print("")
            print("Your final score is {}/100".format(score))
            print("")
            sleep(0.5)
            print("It seems that you have mastered at least half of the knowledge.!!")    
#if score less than 50, print the correspond message
    else:
        print("")
        print("Your final score is {}/100".format(score))
        print("")
        sleep(0.5)
        print("Keep trying and you will be better!!")            

        

def countdown():

    global time

    time=total_time

    for i in range(total_time):
        time=time-1
        sleep(1)
#if player has answered all 10 question, break the for loop. This is used to stop the countdown when the player finishes and record the time that the player used
        if answer_question==10:
            break
#If the player answer the question within the specified time, don't print the time out message. 
    if answer_question==10:
        pass
#If the player does not answer the question within the specified time, print the time out message.
    else:
        print("")
        print("\nSorry, time out!")
        sleep(1)
        print("Checking the answer. Please wait......")
        sleep(2.5)
        print("")
        print("Detail of the Mark:")
        sleep(0.5)
#run i from 1 to 10
        for i in range(1,11,1):
#if the question_number equal to the number between 1 and 10, print the correspond message     
            if question_number==i:
#print the player's answer in the player_answer_list in order.
                for order in range(0,10,1):
                    print("{}. {}".format(order+1, player_answer_list[order]))
#if the player's answer is right, print ""
                    if player_answer_list[order]=="Right":
                        print("")
                        sleep(0.5)
#if the player's answer is wrong, print the correct answer and explanation
                    elif player_answer_list[order]=="Wrong":
                        print("Correct answer:{}".format(correct_choices[order]))
                        sleep(0.5)
                        print("Explanation: {}".format(answers[order]))
                        print("")
                        sleep(0.5)
#if it has printed the question but player did not answer it when the time out, it will still print the correct answer and explanation
                    elif order in range(i-1,i,1):
                        print("Correct answer:{}".format(correct_choices[order]))
                        sleep(0.5)
                        print("Explanation: {}".format(answers[order]))
                        print("")
                        sleep(0.5)
#if the player's answer is no answer which means the player did not see the question, it will print nothing but "" 
                    elif player_answer_list[order]=="No answer":
                        print("")
                        sleep(0.5)
                final_score()                                    
        
#run countdown in the background when the question start printing
countdown_thread = threading.Thread(target = countdown)
countdown_thread.start()

#while the player answers question less than 10, print the question and choice, then input the answer
while answer_question <10:
#run i from 0 to 50 with the step of 5
    for i in range(0,50,5):
#print the question and choice of each quiz question
        print(questions[i])
        sleep(0.5)
#if time out, break the loop, stop printing the question and choice.
        if time==0:
            break                   
        print(questions[i+1])
        sleep(0.5)
        if time==0:
            break                      
        print(questions[i+2])
        sleep(0.5)
        if time==0:
            break                  
        print(questions[i+3])
        sleep(0.5)
        if time==0:
            break              
        print(questions[i+4])
        sleep(0.5)
        if time==0:
            break
#after print all the question and choice, question_number equal to question number+1 
        question_number=question_number+1
#Input the answer
        answer=input("Please enter your answer(Choose A,B,C,D): ")
        answer=answer.upper()
        if time==0:
            break
        print("")
#if answer equal to the correspond answer in the correct answer list, use right to replace the "No answer" in the correspond position in the player_answer_list and add ten score
        if answer==correct_choices[question_number-1]:
            player_answer_list[question_number-1]="Right"
            score=score+10
            answer_question=answer_question+1
#if answer not equal to the correspond answer in the correct answer list, use wrong to replace the "No answer" in the correspond position in the player_answer_list
        else:
            player_answer_list[question_number-1]="Wrong"
            answer_question=answer_question+1
    break
#if the player has answered 10 question in a specified time, print the correspond messege
if answer_question==10:
#print the time that the user use to answer the question.
    print("You used {} second to finish the quiz".format(total_time-time))
    sleep(1.0)
#print the checking answer message
    print("Checking the answer. Please wait......")
    print("")
    sleep(2.5)
    print("Detail of the Mark:")
    sleep(0.5)
#print the player's answer in the player_answer_list in order.
    for order in range(0,10,1):
        print("{}. {}".format(order+1, player_answer_list[order]))
#if the answer equal to right, only print""
        if player_answer_list[order]=="Right":
            print("")
            sleep(0.5)
#if the answer equal to worng, print the explanation and correct answer.
        if player_answer_list[order]=="Wrong":
            print("Correct answer:{}".format(correct_choices[order]))
            sleep(0.5)
            print("Explanation: {}".format(answers==[order]))
            print("")
            sleep(0.5)    
#run final_score function
    final_score()

        