from this import d
from time import*
import threading
import time

# Make the player's answer list. In the beginning, all the answers were "No answers"
player_answer_list=[]
for i in range(0,10,1):
    player_answer_list.append("No answer")
    
#Here are the question list where contains all the quiz questions
questions = ["Question 1: What is the symbol for sodium element? )","(A) Na","(B) Mg", "(C) K", "(D) S",
            
            "2. does all the organic compounds contain the carbon atom?:", "(A) Yes", "(B) No", "(C) some of them", "(D) none of them are correct",

             "3. How many electrons does sodium atom have?: ", "(A) 10", "(B) 11", "(C) 14", "(D) 17",

             "4.what is the symbol for carbon?",  "(A) C", "(B) O", "(C) K", "(D) Cl",

             "5. what is the electron arrangement of magnesium?", "(A) 2,8", "(B) 2,8,1",  "(C) 2,8,3", "(D) 2,8,2",
            
            "6. what is the electron arrangement of potassium> ", "(A) 2,8,8,1", "(B) 2.8,8", "(C) 2,8,8,2", "(D) 2,8,8,3",

            "7. What is Zn? ", "(A) Magnesium", "(B) Hydrogen", "(C) Gold", "(D) Zinc",

            "8.  DNA codes for proteins, which are the building blocks of organisms. What is the most abundant protein in the human body? ", "(A) Keratin", "(B) Tubulin", "(C) Albumin", "(D) Collagen",

            "9.What is the most common isotope of hydrogen?", "(A) protium", "(B) Deuterium", "(C) Tritum", "(D) None", 

            "10.What is its chemical formula for water?", "(A) H2O2", "(B) O2", "(C) H20", "(D) H2"] 


#correct chouices list
correct_choices = ["A","B","B","A","D","A","B","D","A","C"] 

#Set the score to 0 in the begining
score=int(0)

#at the beginning it will 0 questions for the user to answer
question_number=0

#the total time of the quiz
total_time=100


answer_question=int(0)

#marking schedule
def final_score():

    if score==5:
        print("")
        print("you need work on harder ")
        

    elif score==8:
        print("you are very close to excellence, an merit grade is been given.")
        
    if score==9:
            print("")
            print("Good Job, an excellence grade is been awarded.")
            print("")


            print("It will be nice if you have study to get the full marks!!!")

    elif score==10:
            print("")
            print("Well done full makrs with excelelence")
            print("")

            print("looks like you are well prepare for you exam!!")
    
    elif score==6:
            print("")
            print("you are very closed to merit an achieved is been awarded.")
            print("")
      
            

    elif score==7:
        print("")
        print("you are very close the excellence grade. a merit grade is been award ")

    else:
        print("")
        print("you really need work harder and harder.")
        print("")

        print("Keep trying and you will be better!! Marking schedule: E= 9-10, M = 7-8 A = 5-6 N = 0-4")            

        
#counting down the time which 100 seoncds
def countdown():

    global time

    time=total_time

    for i in range(total_time):
        time=time-1
        sleep(1)

        if answer_question==10:
            break

    if answer_question==10:
        pass
    #if time is runs out then print this measage
    else:
        print("")
        print("\nSorry, your time is out!")
        sleep(1)
        print("Marking the answer.")
        sleep(2)
        print("")
        print("Your result:")
        sleep(0.5)
    #this is just to make sure that if the users answer are meeting the correct answer  and if they are right, it will be rihgt and if the users got it wrong, it will print the correct option from the list.
        for i in range(1,11,1):
  
            if question_number==i:

                for order in range(0,10,1):
                    print("{}. {}".format(order+1, player_answer_list[order]))

                    if player_answer_list[order]=="Right":
                        print("")
                        sleep(0.5)

                    elif player_answer_list[order]=="Wrong":
                        print("Correct answer:{}".format(correct_choices[order]))
                     

                    elif player_answer_list[order]=="No answer":
                        print("")
                        sleep(0.5)
                final_score()                                    
        
#this is the counting so once the quiz staeted, it will start counting down the time limit
countdown_thread = threading.Thread(target = countdown)
countdown_thread.start()

while answer_question <10:

    for i in range(0,50,5):

        print(questions[i])
        sleep(0.5)

        if time==0:
            break                   
        print(questions[i+1])
        sleep(0.5)
        if time==0:
            break                      
        print(questions[i+2])
        sleep(0.5)
        if time==0:
            break                  
        print(questions[i+3])
        sleep(0.5)
        if time==0:
            break              
        print(questions[i+4])
        sleep(0.5)
        if time==0:
            break

        question_number=question_number+1
#Input the answer
        answer=input("please select your answer:")
        answer=answer.upper()
        if time==0:
            break
        print("")
# if users got the question right then therefore gain one mark
        if answer==correct_choices[question_number-1]:
            player_answer_list[question_number-1]="Right"
            score=score+1
            answer_question=answer_question+1
#of the users diddn;t get the quiestion right then there it tells its wrong and giving the correct answer
        else:
            player_answer_list[question_number-1]="Wrong"
            answer_question=answer_question+1
    break

if answer_question==10:

    print("You used {} second to finish the quiz".format(total_time-time))
    sleep(1.0)

    print("Marking the answer")
    print("")

    print("Your result:")
    sleep(0.5)

    for order in range(0,10,1):
        print("{}. {}".format(order+1, player_answer_list[order]))

        if player_answer_list[order]=="Right":
            print("")
            sleep(0.5)

        if player_answer_list[order]=="Wrong":
            print("Correct answer:{}".format(correct_choices[order]))
            sleep(0.5)

    final_score()

        