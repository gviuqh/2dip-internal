
from time import*
import threading
import time

name=""

print("Welcome to chemistry quiz that can help you to study for your end of year exam ")

while name=="":
    name=input("Please enter your name").strip()
    name=name.capitalize()

    age = input("Please Enter Your Age: ")
  

print("Hi {}! You have 100 seconds to complete the quiz!".format(name))
time.sleep(1.0)
answer=input("if you are ready to do this quiz, press yes to start")
answer=answer.lower()

while True:
    if answer=="yes" or "Yes":
        print("please wait for three seconds we printing the questions")
        time.sleep(1)
       
        time.sleep(1)
        
        time.sleep(1)
        print("Hope you do well in this quiz!")
        time.sleep(1)
        break
    else:
        print("please answer yes!")
        time.sleep(1)
        answer=input("Please type yes to start: ")
        answer=answer.lower()

import question